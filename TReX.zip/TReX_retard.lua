TReX.retard = TReX.retard or {}


-- TReX.retard.retard_check = function()

-- if t.class.magi.enabled and not t.affs.aeon and 

-- end


TReX.retard.override=function()

--when we want cure.
if not TReX.serverside.am_free() or not (TReX.serverside.am_capable() and t.affs.prone) or not TReX.serverside.am_functional() or TReX.serverside.amProneAndBroke() then
	
else
end

end

--save retard file
TReX.retard.save=function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_retard.lua"
   table.save(savePath, TReX.retard)
end -- func

--load retard file
TReX.retard.load=function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_retard.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.retard)
	end -- if
end -- func

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.retard loaded successfully) ") end

TReX.retard.save()

for _, file in ipairs(TReX.retard) do
	dofile(file)
end -- for
