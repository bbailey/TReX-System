-- TReX.v
-- Vitals tracking

local send							= send
local cc							= TReX.config.cc or "##"

local sipMaxHealth					= 1  --// 0 		= use average, 1 		= use max
local sipMaxMana					= 1  --// 0 		= use average, 1 		= use max
local mossHealthDiff				= 15 --// set to percentage below sipHeath threshold to use moss/potash, recommended 10 to 15
local mossManaDiff					= 15 --// set to percentage below sipMana threshold to use moss/potash, recommended 10 to 15

TReX.pingList=TReX.pingList or {}

registerAnonymousEventHandler("DataSendRequest",     	"TReX.addPing")
registerAnonymousEventHandler("gmcp.Char.Vitals",		"TReX.v.eventhandler")
registerAnonymousEventHandler("TReX lost bal",			"TReX.bals.update")
registerAnonymousEventHandler("TReX gained bal",		"TReX.bals.update")

--save v file
TReX.v.save=function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_v.lua"
   table.save(savePath, TReX.v)
end -- func

--load v file
TReX.v.load=function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_v.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.v)
	end -- if
end -- func

TReX.v.sip_full_health=function()
	if TReX.stats.h < TReX.stats.maxh then
		if t.bals.sip then
			t.send("queue prepend eqbal sip health",false)
		end
			tempTimer(.2, [[
				if TReX.stats.h >= TReX.stats.maxh then
					t.serverside.green_echo("full health")
				--else
					--TReX.v.sip_full_health()
				end
				]])
	end

	if TReX.stats.m < TReX.stats.maxm then
		if t.bals.sip then
			t.send("queue prepend eqbal sip mana",false)
		end
			tempTimer(.2, [[
				if TReX.stats.m >= TReX.stats.maxm then
					t.serverside.green_echo("full mana")
				--else
					--TReX.v.sip_full_health()
				end
				]])
	end
end

TReX.v.eventhandler=function()

if t.serverside["settings"].installed then
	--if gmcp then
		--if gmcp.Char then
			--if gmcp.Char.Vitals then
			
-- local new = tonumber(gmcp.Char.Vitals.maxhp)
-- 	 if (new ~= TReX.v.maxhp) then 
	
-- 	 	TReX.v.sipHealth	= 100-math.floor(100*math.floor((1+(t.serverside["settings"].sipRingHealth/10)) * ((0.15+sipMaxHealth*0.03) * tonumber(gmcp.Char.Vitals.maxhp) + 70 + sipMaxHealth*12))/tonumber(gmcp.Char.Vitals.maxhp))
-- 	 	TReX.v.sipMana		= 100-math.floor(100*math.floor((1+(t.serverside["settings"].sipRingMana/10)) * ((0.15+sipMaxMana*0.03) * tonumber(gmcp.Char.Vitals.maxmp) + 70 + sipMaxMana*12))/tonumber(gmcp.Char.Vitals.maxmp))
-- 	 	TReX.v.mossHealth	= 95
-- 	 	TReX.v.mossMana		= TReX.v.sipMana + 10
-- 	 	TReX.v.maxhp		= new

-- 	 	t.send("CURING SIPHEALTH "..TReX.v.sipHealth..cc.."CURING SIPMANA "..TReX.v.sipMana..cc.."CURING MOSSHEALTH "..TReX.v.mossHealth..cc.."CURING MOSSMANA "..TReX.v.mossMana)
-- 	 	t.send("CURING HEALTHAFFSABOVE "..TReX.v.sipHealth + (t.serverside["settings"].sipRingHealth or 1)-50) -- a good starting point..
				
-- 	 	TReX.config.display("Resetting Sip Thresholds")

-- 	 	local newmana = tonumber(gmcp.Char.Vitals.maxhp)	

-- 	 end

if t.bals.bal == nil then
	t.bals.bal = true
end

if t.bals.eq == nil then
	t.bals.eq = true
end

if t.bals.voice == nil then
	t.bals.voice = true
end

if t.bals.sip == nil then
	t.bals.sip = true
end

if t.bals.immunity == nil then
	t.bals.immunity = true
end

if t.bals.tree == nil then
	t.bals.tree = true
end

if t.bals.focus == nil then
	t.bals.focus = true
end

if t.bals.fitness == nil then
	t.bals.fitness = true
end

if t.bals.bloodboil == nil then
	t.bals.bloodboil = true
end

if t.bals.rage == nil then
	t.bals.rage = true
end

if t.bals.salve == nil then
	t.bals.salve = true
end

if t.bals.herb == nil then
	t.bals.herb = true
end

if t.bals.smoke == nil then
	t.bals.smoke = true
end

if t.bals.alleviate == nil then
	t.bals.alleviate = true
end

if t.bals.accelerate == nil then
	t.bals.accelerate = true
end



	-------------------------------------------------------------------------
	-- BALANCE TRACKING -----------------------------------------------------
	-------------------------------------------------------------------------
	if (t.bals.bal) then
		if not (TReX.u.toBoolean(gmcp.Char.Vitals.bal)) then

			raiseEvent("TReX lost bal", "bal")

			local what = "<DarkSlateGrey>(<red>-<DarkSlateGrey>) <red>[<DarkSlateGrey>Balance<red>]" 
												
				if (t.serverside["settings"].echos) then
					moveCursorEnd("main")
						if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
				  		
				end
						
			t.bals.balTime = t.bals.balTime or {}
			balStopWatch = createStopWatch()
			startStopWatch( tonumber(balStopWatch) )

				if balTimer then killTimer(balTimer) end					
					balTimer = tempTimer(TReX.averageListResult(t.bals.balTime), [[
						
						--TReX.config.display("(*) Balance Timer")
						t.bals["bal"] = true
						TReX.serverside.treeAffLost("trackable_event lost")
					
							if TReX.u.toBoolean(gmcp.Char.Vitals.bal) then
								
							local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Balance<green>]" 
										
										
							if (t.serverside["settings"].echos) then
								moveCursorEnd("main")
								if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
							  		--cecho(what)
							 end
						
							raiseEvent("TReX gained bal", "bal")
							if balTimer then killTimer(balTimer) end


							balTime = stopStopWatch( balStopWatch ) 
							balTime = balTime - getNetworkLatency()


							-- if return greater than average list result then dont insert to compenstate for latency
							if #t.bals.balTime>1 then
								if balTime < TReX.averageListResult(t.bals.balTime)+1-(getNetworkLatency()*.1) and balTime > TReX.averageListResult(t.bals.balTime)-1-(getNetworkLatency()*.1) then
							 		return
							 	else
							 		table.insert(t.bals.balTime, 1, TReX.averageListResult(t.bals.balTime))
							 	end
							else
								table.insert(t.bals.balTime, 1, balTime)										
							end

								if #t.bals.balTime > 10 then
						    		table.remove(t.bals.balTime, 11)
						  		end
									resetStopWatch( balStopWatch )


							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
									moveCursorEnd("main")
									if getCurrentLine() == "" and not t.serverside.def_check then cecho(" : [ " .. balTime .. " ] ") end 
								end
							end

						
						]])	

					 --timestamp for balances
							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
							 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
									moveCursorEnd("main")
										if getCurrentLine() == "" and not t.serverside.def_check then cecho("\t<dim_grey>"..timestamp) end
				 				end
							end
					

		end
	else
		if TReX.u.toBoolean(gmcp.Char.Vitals.bal) then
			raiseEvent("TReX gained bal", "bal")
			
			local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Balance<green>]" 
													
				if (t.serverside["settings"].echos) then
					moveCursorEnd("main")
					if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
				  		--cecho(what)
				end
								
				if balTimer then killTimer(balTimer) end

					 --timestamp for balances
						 if (t.serverside["settings"].echos) then
						 	if t.serverside["settings"].timestamp then
						 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
								moveCursorEnd("main")
				 				if getCurrentLine() == "" and not t.serverside.def_check then cecho("\t<dim_grey>"..timestamp) end
							end
						 end

							balTime = stopStopWatch( balStopWatch ) 
							balTime = balTime - getNetworkLatency()


								-- if return greater than average list result then dont insert to compenstate for latency
							if #t.bals.balTime>1 then
								if balTime < TReX.averageListResult(t.bals.balTime)+1-(getNetworkLatency()*.1) and balTime > TReX.averageListResult(t.bals.balTime)-1-(getNetworkLatency()*.1) then
							 		return
							 	else
							 		table.insert(t.bals.balTime, 1, TReX.averageListResult(t.bals.balTime))
							 	end
							else
								table.insert(t.bals.balTime, 1, balTime)										
							end


								if #t.bals.balTime > 10 then
						    		table.remove(t.bals.balTime, 11)
						  		end
									resetStopWatch( balStopWatch )						

							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
									moveCursorEnd("main")
									if getCurrentLine() == "" and not t.serverside.def_check then cecho(" : [ " .. balTime .. " ] ") end 
									--cecho(" : [ " .. balTime .. " ] ")
								end
							end


		end
	end
	----------------------------------------------------------------------------
	-- EQUILIBRIUM TRACKING-----------------------------------------------------
	----------------------------------------------------------------------------
	if (t.bals.eq) then
		if not (TReX.u.toBoolean(gmcp.Char.Vitals.eq)) then
			raiseEvent("TReX lost bal", "eq")

			--local what = "<DarkSlateGrey>(<red>-<DarkSlateGrey>) <red>[<DarkSlateGrey>Equilibrium<red>]" 
												
				--if (t.serverside["settings"].echos) then
				--	moveCursorEnd("main")
				--		if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
				  		
				--end
						
			t.bals.eqTime = t.bals.eqTime or {}
			eqStopWatch = createStopWatch()
			startStopWatch( tonumber(eqStopWatch) )

				if eqTimer then killTimer(eqTimer) end					
					eqTimer = tempTimer(TReX.averageListResult(t.bals.eqTime), [[
						
						--TReX.config.display("(*) Equilibrium Timer")
						t.bals["eq"] = true
						TReX.serverside.treeAffLost("trackable_event lost")
					
							if TReX.u.toBoolean(gmcp.Char.Vitals.eq) then
								
							local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Equilibrium<green>]" 
																
							if (t.serverside["settings"].echos) then
								moveCursorEnd("main")
								if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
							  		--cecho(what)
							 end
						
							raiseEvent("TReX gained bal", "eq")
							if eqTimer then killTimer(eqTimer) end


							eqTime = stopStopWatch( eqStopWatch ) 
							eqTime = eqTime - getNetworkLatency()


							-- if return greater than average list result then dont insert to compenstate for latency
							if #t.bals.eqTime>1 then
								if eqTime < TReX.averageListResult(t.bals.eqTime)+1-(getNetworkLatency()*.1) and eqTime > TReX.averageListResult(t.bals.eqTime)-1-(getNetworkLatency()*.1) then
							 		return
							 	else
							 		table.insert(t.bals.eqTime, 1, TReX.averageListResult(t.bals.eqTime))
							 	end
							else
								table.insert(t.bals.eqTime, 1, eqTime)										
							end

								if #t.bals.eqTime > 10 then
						    		table.remove(t.bals.eqTime, 11)
						  		end
									resetStopWatch( balStopWatch )


							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
									moveCursorEnd("main")
									if getCurrentLine() == "" then and not t.serverside.def_check cecho(" : [ " .. eqTime .. " ] ") end 
								end
							end

						
						]])	

					 --timestamp for balances
							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
							 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
									moveCursorEnd("main")
										if getCurrentLine() == "" and not t.serverside.def_check then cecho("\t<dim_grey>"..timestamp) end
				 				end
							end


	

		end
	else
		if TReX.u.toBoolean(gmcp.Char.Vitals.eq) then
			raiseEvent("TReX gained bal", "eq")
			
			local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Equilibrium<green>]" 
													
				if (t.serverside["settings"].echos) then
					moveCursorEnd("main")
					if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
				  		--cecho(what)
				end
								
				if balTimer then killTimer(balTimer) end

					 --timestamp for balances
						 if (t.serverside["settings"].echos) then
						 	if t.serverside["settings"].timestamp then
						 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
								moveCursorEnd("main")
				 				if getCurrentLine() == "" and not t.serverside.def_check then cecho("\t<dim_grey>"..timestamp) end
							end
						 end

							eqTime = stopStopWatch( eqStopWatch ) 
							eqTime = eqTime - getNetworkLatency()


								-- if return greater than average list result then dont insert to compenstate for latency
							if #t.bals.eqTime>1 then
								if eqTime < TReX.averageListResult(t.bals.eqTime)+1-(getNetworkLatency()*.1) and eqTime > TReX.averageListResult(t.bals.eqTime)-1-(getNetworkLatency()*.1) then
							 		return
							 	else
							 		table.insert(t.bals.eqTime, 1, TReX.averageListResult(t.bals.eqTime))
							 	end
							else
								table.insert(t.bals.eqTime, 1, eqTime)										
							end


								if #t.bals.eqTime > 10 then
						    		table.remove(t.bals.eqTime, 11)
						  		end
									resetStopWatch( eqStopWatch )						

							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
									moveCursorEnd("main")
									if getCurrentLine() == "" and not t.serverside.def_check then cecho(" : [ " .. eqTime .. " ] ") end 
									--cecho(" : [ " .. eqTime .. " ] ")
								end
							end


		end
	end
	-------------------------------------------------------------------------
	-- VOICE TRACKING -------------------------------------------------------
	-------------------------------------------------------------------------

	if (t.bals.voice) then
	 	if not (table.contains(gmcp.Char.Vitals.charstats, "Voice: Yes")) then
	 		raiseEvent("TReX lost bal", "voice")
			moveCursorEnd("main")
			local what = "<DarkSlateGrey>(<red>-<DarkSlateGrey>) <red>[<DarkSlateGrey>Voice<red>]" 
					
			if (t.serverside["settings"].echos) then
				moveCursorEnd("main")
				if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) --[[what = "\n"..what]] end
			  		--cecho(what)
			end

			t.bals.voiceTime = t.bals.voiceTime or {}
			voiceStopWatch = createStopWatch()
			startStopWatch( tonumber(voiceStopWatch) )

				if voiceTimer then killTimer(voiceTimer) end					
					voiceTimer = tempTimer(TReX.averageListResult(t.bals.voiceTime), [[
					
						--TReX.config.display("(*) Voice Timer")
						t.bals["voice"] = true
						TReX.serverside.treeAffLost("trackable_event lost")

						if TReX.u.toBoolean(gmcp.Char.Vitals.voice) then
						
							local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Voice<green>]" 
										
							if (t.serverside["settings"].echos) then
								moveCursorEnd("main")
								if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end
							  		--cecho(what)
							end
				
							if voiceTimer then killTimer(voiceTimer) end


							voiceTime = stopStopWatch( voiceStopWatch ) 
							voiceTime = voiceTime - getNetworkLatency()
							

						-- if return greater than average list result then dont insert to compenstate for latency
						if #t.bals.voiceTime>1 then
							if voiceTime < TReX.averageListResult(t.bals.voiceTime)+1-(getNetworkLatency()*.1) and voiceTime > TReX.averageListResult(t.bals.voiceTime)-1-(getNetworkLatency()*.1) then
						 		return --table.insert(t.bals.voiceTime, 1, voiceTime)
						 	else
						 		table.insert(t.bals.voiceTime, 1, TReX.averageListResult(t.bals.voiceTime))
						 	end
						else
							table.insert(t.bals.voiceTime, 1, voiceTime)										
						end

								if #t.bals.voiceTime > 10 then
						    		table.remove(t.bals.voiceTime, 11)
						  		end
									resetStopWatch( voiceStopWatch )

					
					]])	

			 --timestamp for balances

					if (t.serverside["settings"].echos) then
						if t.serverside["settings"].timestamp then
					 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
							moveCursorEnd("main")
							if getCurrentLine() == "" and not t.serverside.def_check then cecho(" : [ " .. eqTime .. " ] ") end 
			 				--cecho("\t<dim_grey>"..timestamp)
			 			end
					end
						

		

		end
	else
		if TReX.u.toBoolean(gmcp.Char.Vitals.voice) then
			raiseEvent("TReX gained bal", "voice")
			moveCursorEnd("main")
			local what  = "<DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[<DarkSlateGrey>Voice<green>]" 
					
												
					if (t.serverside["settings"].echos) then
						moveCursorEnd("main")
						if getCurrentLine() == "" and not t.serverside.def_check then cecho(what) end 
					  		--cecho(what)
					end
							
						if voiceTimer then killTimer(voiceTimer) end

							 --timestamp for balances
							if (t.serverside["settings"].echos) then
								if t.serverside["settings"].timestamp then
							 		timestamp = tostring(getTime(true,"hh:mm:ss:zzz"))
									moveCursorEnd("main")
									if getCurrentLine() == "" and not t.serverside.def_check then cecho("\t<dim_grey>"..timestamp) end 
					 				--cecho("\t<dim_grey>"..timestamp)
					 			end
							end

							voiceTime = stopStopWatch( voiceStopWatch ) 
							voiceTime = voiceTime - getNetworkLatency()

								-- if return greater than average list result then dont insert to compenstate for latency
								if #t.bals.voiceTime>1 then
									if voiceTime < TReX.averageListResult(t.bals.voiceTime)+1-(getNetworkLatency()*.1) and voiceTime > TReX.averageListResult(t.bals.voiceTime)-1-(getNetworkLatency()*.1) then
								 		return --table.insert(t.bals.voiceTime, 1, voiceTime)
								 	else
								 		table.insert(t.bals.voiceTime, 1, TReX.averageListResult(t.bals.voiceTime))
								 	end
								else
									table.insert(t.bals.voiceTime, 1, voiceTime)										
								end

								--remove oldest from table
								if #t.bals.voiceTime > 10 then
						    		table.remove(t.bals.voiceTime, 11)
						  		end
									resetStopWatch( voiceStopWatch )

							if (t.serverside["settings"].echos) then
								moveCursorEnd("main")
								if getCurrentLine() == "" and not t.serverside.def_check then cecho(" : [ " .. voiceTime .. " ] ") end 
								--cecho(" : [ " .. voiceTime .. " ] ")
							end


		end

	end

end
end

TReX.bals.entity_bal_check=function()
	for _, stat in ipairs(gmcp.Char.Vitals.charstats) do 
		if stat:starts("Entity:") then 
			t.bals["entity"] = tostring(stat:match("^Entity: (%w+)"))
			
			if t.bals.entity == "Yes" then
				return true
			else 
				return false
			end
			
		end 
			
	end
end

TReX.bals.update=function(event, arg)
	if event:find("gained bal") then
		t.bals[arg] = true  	
	else
		t.bals[arg] = false     

	end
end

--return my ping
TReX.myPing=function()
  return TReX.averageListResult(TReX.pingList)
end

TReX.addPing=function ()
  table.insert(TReX.pingList, 1, getNetworkLatency())
  if #TReX.pingList > 10 then
    table.remove(TReX.pingList, 11)
  end
end

TReX.averageListResult=function (l)
  local i = #l
  local acc = 0
  for k,v in pairs(l) do
    acc = acc + v
  end --for
  return acc / i
end

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.v loaded successfully) ") end

TReX.v.save()

for _, file in ipairs(TReX.v) do
	dofile(file)
end -- for