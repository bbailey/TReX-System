-- TReX.config
-- System config

local send							= send
local cc							= TReX.config.cc or "##"
local g 							= "<dark_slate_gray:black>"
local b 							= "<blue:black>"
        
TReX.config.onpromptfuncs = {}

TReX.graphic = [[<white>

                  (O)
                   /|						
                   o<M      
                  /:M+=-------------------------------------,,,,,,
    (O)[]XXXXXXXXI{<white>+}::<===<{H}>==<>==<>==<>==<>==<>==<>==<>------------>
                  \:W+=-------------------------------------''''''
                   o<W
                   \|
                  (O)
       
]]

-- MENUS
TReX.menus = {
main = ""..
TReX.graphic..[[   
<white>			      TReX  

<light_slate_grey> 			     ]]..TReX.myVersion..[[

<dim_gray>          
		about			api
		help file 		setup
		prompt			bugs
		lust			precache		
		tree			settings
		mount list		prios				
		defup			inventory
		keepup			clan info
		defs			projects (todo)
		development
		
]].."",

-- HELP

misc = ""..   
TReX.graphic..[[
<white>			Misc 
            	
<white>	System Commands:<gray>

<gray>	Playlist <LightSlateGray>	[<gray>	on<LightSlateGray>	|<gray>	off<LightSlateGray>	]
<gray>	Daydream
  

]].."", 

-- SETUP
setup = ""..   
TReX.graphic..[[
<white>			Setup

<gray>	Step 1) <dim_gray>	Download Mudlet 3.0 or greater.
<gray>	Step 2) <dim_gray>	Create NEW profile. Enable GMCP. Enable FORCE COMPRESSION OFF.
<gray>	Step 3) <dim_gray>	Package TReX.mpackage in the package manager.
<gray>	Step 4) <dim_gray>	Empty Pipes.
<gray>	Step 5) <dim_gray>	Restart.
<gray>	Step 6) <dim_gray>	INSTALL
<gray>	Step 7) <dim_gray>	Configure TReX system settings.
<gray>	Step 8) <dim_gray>	QQ and RESTART mudlet Mudlet 3.0 or greater.

	<gray>	- <dim_gray>	Toggle defences with DD
	<gray>	- <dim_gray>	Look through your aliases, 
	<gray>	- <dim_gray>	Play with the menus. 
 

]].."", 

-- ABOUT
about = ""..
TReX.graphic..[[
<white>			About
<dim_gray>

	What is TReX?  It is a very powerful healing system designed to be light
	and comfortable and making using serverside curing as comfortable and 
	seemless as possible. It uses gmcp to track afflictions and just about 
	everything gmcp can track up-to-date. 

<gray>	
	
	Here's a list of some of the features that comprise the system.
	
          <white>-<dim_gray>GMCP affliction tracking.
          <white>-<dim_gray>GMCP class change detection.
          <white>-<dim_gray>GMCP dragon form detection.
          <white>-<dim_gray>Interactive Prompt.
          <white>-<dim_gray>Mount Handling.
          <white>-<dim_gray>Event Handling.	

<gray>	For the up-to-date version, see: 
		
]].."",

-- DEVELOPMENT
development = ""..
TReX.graphic..[[
<white>			Development
<dim_gray>
	TReX was started in October 2015, by me (Nehmrah) with the help of some individuals
	without whose help the project wouldn't have been possible.  A big thanks
	to the following people/players! :
	 
<LightSlateGray>	Inspired By:<white>	Vadimuses, Carmain, Nemutaur
<LightSlateGray>	The Brains:<white>	Mindshell, Jhui, Seragorn
<LightSlateGray>	Developers:<white>	Nehmrah, Klendathu, Keneanung
<LightSlateGray>	Testers:<white>	Lucianus, Invictus, Roagnak, Dajio, Drefan, Deladan,
		Aegoth, Daslin .. and others!

]].."\n\n",

-- API
api = ""..
TReX.graphic..[[
<white>			API

<white>*<dim_gray>IN DEVELOPMENT<white>*
	
<white>You can ask for a clan invite from Nehmrah or Klendathu.
]].."", 

-- BUG
bug = ""..
TReX.graphic..[[
<white>			Bugs

<gray>	Step 1) <dim_gray>	Click the link below to create a new issue.
 
<gray>	Step 2) <dim_gray>	Check the Issue list for your bug to see if it has already been issued.

<gray>	Step 3) <dim_gray>	Use images if possible and give as much information as to what is causing the issue.

]].."",

-- PROJECTS
projects = ""..
TReX.graphic..[[
<white>			Projects

<gray>	Step 1) <dim_gray>	Click the link below to create a new project.
 
<gray>	Step 2) <dim_gray>	Check the Projects list on git for your desired project/update/idea/change 
		to see if it has already been listed as a to-do.
		
<gray>	Step 3) <dim_gray>	Try to be clear on what it is you would like added or changed, and provide any 
		available examples.

]].."",

-- HELP
help = ""..
TReX.graphic..[[
<white>			Help

<white>*<dim_gray>IN DEVELOPMENT<white>*
	
<white>You can ask for a clan invite from Nehmrah or Klendathu.

<dim_gray>System Commands:<gray>
]].."",

-- CLAN
clan = ""..
TReX.graphic..[[
<white>			Clan

<white>*<dim_gray>IN DEVELOPMENT<white>*
	
<white>You can ask for a clan invite from Nehmrah or Klendathu.
]].."",

}

registerAnonymousEventHandler("login load", "TReX.config.login_load")
registerAnonymousEventHandler("gmcp.IRE", "TReX.stats.custom_prompt_flag")
registerAnonymousEventHandler("gmcp.Room", "TReX.stats.custom_prompt_flag")
registerAnonymousEventHandler("gmcp.Comm", "TReX.stats.custom_prompt_flag")
registerAnonymousEventHandler("gmcp.Char.Status",	"TReX.stats.custom_prompt_flag")
registerAnonymousEventHandler("gmcp.Char.Items.Update",	"TReX.stats.custom_prompt_flag")
registerAnonymousEventHandler("gmcp.Char.Vitals", "TReX.serverside.conditional_report")
--registerAnonymousEventHandler("gmcp.Char.Vitals", "TReX.stats.custom_prompt_flag")

TReX.config.login_load=function(event)

	TReX.config.loadSettings()
	
		if t.serverside["settings"].installed then

				--settings
			TReX.serverside.login_settings() 
			TReX.prios.default_settings()
			TReX.prios.reset()
			TReX.class.reset()  
			TReX.defs.login()  
			TReX.prios.login_reset()  
			TReX.pipes.settings()  

			--affbar
			setBorderBottom(0)
			t.serverside.border_bottom=0
			t.serverside.affbar = false
			TReX.serverside.middle:setBold(true)
			setMiniConsoleFontSize("TReX.serverside.middle", 12)
			TReX.serverside.affbar("on")
			
			--serverside config
			if not TReX.config.cc then
				t.send("config",false)  
			end
		
			--serverside curing status
			TReX.parry.on = false
			t.send("curing status", false) 

				setMiniConsoleFontSize("TReX.serverside.middle", 12)
			
			TReX.user	= gmcp.Char.Status.name
			if TReX.user=="Nehmrah" then
				tgz.affbar.toggle("on")
				tgz.affbar.middle:setBold(true)
				setMiniConsoleFontSize("tgz.affbar.middle", 12)
			end
			
				tempTimer(1, [[t.serverside["settings"].sys_loaded = true]]) 
				playSoundFile(getMudletHomeDir().. [[/TReX/TReX.mp3]])
				
		else
			t.echo("TReX not installed, or the file is corrupt; best to reinstall.", false)
		end
		
end

TReX.config.install=function()

	--install
	TReX.defs.list()
	--TReX.defs.skillcheck()
	TReX.serverside.settings() 
	TReX.serverside.tree_by_class()	
	TReX.prios.default_settings()
	TReX.prios.reset()
	TReX.precache.settings() 
	TReX.stats.settings()
	TReX.pipes.settings()
	TReX.config.settings()
	TReX.config.score_sheet()
	--TReX.config.color_sheet()
	--TReX.config.saveDefences()
	
	--if gmcp.Char.Status.name == "Nehmrah" then TReX.config.allowtells() end
	t.send("config",false)
	t.serverside["settings"].installed = true

end

t.send=function(line, boolean)
	if not (TReX.serverside.inslowcuringmode() --[[and not t.affs.stun]] and not t.serverside["settings"].paused) and not (t.affs.aeon_override) then
		if boolean ~= nil then
			send(line, boolean)
		else
			sendAll(line)
		end
	else	
		tempTimer(2.2, [[
			if boolean ~= nil then
				send(line, boolean)
			else
				sendAll(line)
			end
		]])
	end
end

TReX.debugMessage=function(message, content)
	if not t.serverside["settings"].debugEnabled then return end
	cecho(string.format("\n<white>[%s]: %s", (debug.getinfo(2).name or "TReX"), message))
	if content then
		display(content)
	end -- if
end -- func

TReX.percentOfValue=function(percent, value)
	result = percent/100 * value
	return result
end

TReX.config.spairs=function(t, order)

    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys 
    if order then
        table.sort(keys, function(a,b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end

TReX.color_rift_percentage=function(perc)  
--print(perc)
	if perc < 1 then
		return "<brown>"
	elseif perc <= 250 then
		return "<red>"
	elseif perc <= 500 then
		return "<dark_orange>"
	elseif perc <= 1500 then
		return "<yellow>"
	else
		return "<DarkKhaki>"
	end
end

TReX.config.deepcopy=function(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

TReX.config.onprompt=function()
	TReX.serverside.BlackoutDetection()
	if t.serverside["settings"].Prompt then
		if isPrompt() then
			TReX.deleteLineP()
			raiseEvent("TReX prompt")
		end
	end
			TReX.serverside.conditional_report()
end

TReX.deleteLineP=function()
	deleteLine()
	tempLineTrigger(1, 1, [[if isPrompt() then selectString(line,1) deleteLine() end]])
end

TReX.config.onprompt_beforeaction_add=function(name, what)
   	TReX.config.onpromptfuncs[name] = what
end

TReX.config.bloodleech=function()
	TReX.config.onprompt_beforeaction_add("deleteLine", function() end)
end

-- this is for blackout, havnt finished it.
TReX.config.setup_prompt=function()
  if line == "-" or line:find("^%-%d+%-$") or line == " Vote-" then
    --t.bals.bal = true
   -- t.bals.eq = true

   --for monks below
   -- t.bals.rightarm = true
   -- t.bals.leftarm = true
  else
    t.bals.bal = false
    t.bals.eq = false
  end
end

TReX.config.highlight=function(self, colour, background, specifics)
	if not specifics then
		if not background then
			selectString(line, 1)
			fg(colour)
			resetFormat()
		else
			selectString(line, 1)
			fg(colour)
			bg(background)
			resetFormat()
		end
	else
		if not background then
			selectString(specifics, 1)
			fg(colour)
			resetFormat()
		else
			selectString(specifics, 1)
			fg(colour)
			bg(background)
			resetFormat()
		end
	end
end

TReX.config.curingEcho=function(type, ailment)
	if t.serverside["settings"].echos then
		if type == "herb" then
			TReX.deleteLineP()	
			--cecho("\n<"..echoSettings.herbColour..">" ..ailment:title().. " Cured!-")
		elseif type == "salve" then
			TReX.deleteLineP()	
			cecho("\n<"..echoSettings.salveColour..">" ..ailment:title().. " Cured!-")
		elseif type == "restoration" then
			TReX.deleteLineP()	
			cecho("\n<"..echoSettings.restorationColour..">"..ailment:title().." Cured!-")
		elseif type == "focus" then
			TReX.deleteLineP()	
			cecho("\n<"..echoSettings.focusColour..">"..ailment:title().." Cured!-")
		elseif type == "smoke" then
			TReX.deleteLineP()	
			cecho("\n<"..echoSettings.smokeColour..">"..ailment:title().." Cured!-")
		elseif type == "passive" then
			TReX.deleteLineP()
			cecho("\n<"..echoSettings.passiveColour..">"..ailment:title().." Cured!-")
		end
	end
end

TReX.config.showMounts=function()

	echo("\n")
	cecho("\n\t<white>Mount List")
	echo("\n")
	for k,v in pairs(mount_list) do 
		if v.number == t.serverside["settings_default"].mount then
			--echo("\n - ") cecho("<light_blue>Current<white>: "..k..""..t.serverside["settings_default"].mount)
			echo("\n - ") cecho("<light_blue>Current<white>: "..t.serverside["settings_default"].mount)
		end
	end
	--echo("\n - ") echoLink("Current Mount: "..t.serverside["settings_default"].mount, "clearCmdLine() appendCmdLine'mount add '", "mount add <name> <id>")
	echo("\n - ") echoLink("Add Mount", "clearCmdLine() appendCmdLine'mount add '", "mount add <name> <id>")
	echo("\n - ") echoLink("Remove Mount", "clearCmdLine() appendCmdLine'mount remove '", "mount remove <name>")
	echo("\n")

local sortMount = {}

  for k,v in pairs(mount_list) do
		sortMount[#sortMount+1] = k
		table.sort(sortMount)
  end

	local x = 0
	 			 
		for i, n in ipairs(sortMount) do
				x = x + 1

		     	d = "<dim_gray>[<white>"


		 		if mount_list[n].enabled then
		 			d = d .. " <light_blue>+ "
		 		else
		 			d = d .. " <red>- "
		 		end


	     		d = d .. "<dim_gray>]<white> " 


				if (x-1)%3 == 0 then
					echo("\n")
				end  
		
		   	local nWithSpace = n:title()

				if nWithSpace:len() < 25 and (x-1) %3~=2 then
					local pad = 25 - nWithSpace:len()
					nWithSpace = nWithSpace .. string.rep(" ", pad)
				elseif nWithSpace:len() > 25 then
					nWithSpace = nWithSpace:cut(25)
		     	end
	 
			local command
				fg("white")
				cecho(d)
			
			local command = [[TReX.config.mount_list_toggle("]]..n..[[")]]
			echoLink(nWithSpace, command, "Toggle " .. n:title(), true)

		end
			echo("\n")
			--TReX.stats.prompt_flag = true
			--raiseEvent("TReX prompt")

end

TReX.config.mount_list_toggle=function(variable)

if type(mount_list[variable].enabled) == "boolean" then
	if toggle ~= nil then
		mount_list[variable].enabled = verify(toggle)
	else
		mount_list[variable].enabled = not mount_list[variable].enabled
	end

		if mount_list[variable].enabled then -- if toggling to true
			mount_list[variable].enabled = true
			
			for k,v in pairs(mount_list) do
				if v.enabled then
					TReX.config.set_mount(v.number)						
						--v.number = t.serverside["settings_default"].mount
				end
			end		
	
		else

				t.send("curing mount 0")
				mount_list[variable].enabled = false
				t.serverside["settings_default"].mount = "No"
			
		end
			
		TReX.config.showMounts()
		
		echo("\n")
		--TReX.stats.prompt_flag = true
		--raiseEvent("TReX prompt")



end 
end

TReX.config.echo=function(what, command, popup) -- sorry this is an echo
t.serverside.cmd_prompt = getLineCount()
	what = "<yellow>[<white>†<yellow>]<reset><white> " .. what
	-- apply newline if required
	moveCursorEnd("main")
	--if string.sub(line, 1, 1) ~= "" then what = "\n"..what end
	if getCurrentLine() ~= "" then what = "\n"..what end
		if command then
			cechoLink(what, command, popup or "", true)
		else
			cecho(what)
		end
		
end -- func

TReX.config.display=function(what, command, popup) -- another echo
t.serverside.cmd_prompt = getLineCount()
	what = "<red>[<white>†<red>]<reset><white> "..what
	-- apply newline if required
	moveCursorEnd("main")
	--if string.sub(line, 1, 1) ~= "" then what = "\n"..what end
	if getCurrentLine() ~= "" then what = "\n"..what end
		if command then
			cechoLink(what, command, popup or "", true)
		else
			cecho(what)
		end

end

TReX.config.pause=function () -- your hard tem pause

	if t.serverside["settings"].paused then
		t.send("curing on", false)
		t.serverside["settings"].paused = false
		if t.serverside["settings"].echos then t.echo(" <DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[ <DarkSlateGrey>CURING <green>] ") end	
			
			if t.serverside["settings_default"].defences == "No" then
				t.serverside["settings_default"].defences = "Yes"
				t.send("curing defences on", false)
				if t.serverside["settings"].echos then t.echo(" <DarkSlateGrey>(<green>+<DarkSlateGrey>) <green>[ <DarkSlateGrey>DEFENCE <green>] ") end
			end
			
				TReX.stats.prompt_flag = true
				raiseEvent("TReX prompt")
				t.send("plist", false)
		
	else		
		t.send("curing off", false)
		t.serverside["settings"].paused = true
		if t.serverside["settings"].echos then t.echo(" <DarkSlateGrey>(<white>-<DarkSlateGrey>) <white>[ <DarkSlateGrey>CURING <white>] ") end

			if t.serverside["settings_default"].defences == "Yes" then
				t.serverside["settings_default"].defences = "No"
				t.send("curing defences off", false)
				if t.serverside["settings"].echos then t.echo(" <DarkSlateGrey>(<white>-<DarkSlateGrey>) <white>[ <DarkSlateGrey>DEFENCE <white>] ") end
			end
			
				TReX.stats.prompt_flag = true
				raiseEvent("TReX prompt")
	end -- if
		-- debugging echos.
	if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.config.pause COMPILED) ") end
end -- func

TReX.config.settings=function() -- this is the settings file, what needs to happen here is it needs to be put into a one time hard vinstall type thing, right now it just runs everytime. I havent done it yet. This could be your file though, the config file.
		
	t.config.settings_default = {

		time_out 					= 10,	
		plants 						= "Yes",
		prompt 						= "all",
		map_show 					= "none",
		page_length 				= 250,
		screen_width 				= 0,
		use_queueing 				= "No",
		loyal_slain_msg 			= "Yes",
		show_self_in_who 			= "No",
		show_queue_alerts 			= "Yes",
		command_separator  			= "cmdsep",
		mxp							= "Yes",
			
	}
		
	t.config.settings_dict = {

		Yes							= "on",
		No 							= "off",
		cmdsep 						= "##",
		plants 						= "plants",
		prompt  					= "prompt",
		map_show 					= "mapshow",
		time_out 					= "timeout",
		roomdesc 					= "brief", -- testing
		page_length 				= "pagelength",
		screen_width 				= "screenwidth",
		use_queueing 				= "usequeueing",
		loyal_slain_msg 			= "loyalslainmsg",
		show_self_in_who			= "showselfinwho",
		show_queue_alerts 			= "showqueuealerts",
		command_separator  			= "commandseparator",

		
		
	}

	for k,v in pairs(t.config.settings_default) do
		if isPrompt() then deleteFull() end
  
			t.send("config " ..(t.config.settings_dict[k] or k).. " " ..(t.config.settings_dict[v] or v), false)
	end

	
end

-- CONFIG 'SCORE' SHEET	
TReX.config.score_sheet=function()	
	
	t.config.score_sheet = {
	
		character 				= {enabled = true},
		about 					= {enabled = true},
		vitals 					= {enabled = true},
		statistics 				= {enabled = true},
		resources 				= {enabled = true},

	}

		
	for k,v in pairs(t.config.score_sheet) do
		if v.enabled then
			if isPrompt() then deleteFull() end
				t.send("config scoreshow add " ..tostring(k), false)
			end
		end

end
	
-- CONFIG 'COLOUR' SETTINGS
TReX.config.color_sheet=function()		

	t.config.color_sheet = {

		--SPECIAL	
		H1						= {fg = 11, bg = 0, enabled = true},	
		H2						= {fg = 3,  bg = 0, enabled = true},	
		H3						= {fg = 2,  bg = 0, enabled = true},	
		H4						= {fg = 6,  bg = 0, enabled = true},
		deathsight				= {fg = 9,  bg = 0, enabled = true},
		balance 				= {fg = 6,  bg = 0, enabled = true},	
		affmessages				= {fg = 6,  bg = 0, enabled = true},
	
		--COMMUNICATION
		says					= {fg = 14, bg = 0, enabled = true},	
		shouts					= {fg = 6,  bg = 0, enabled = true},	
		tells					= {fg = 11, bg = 0, enabled = true},	
		HNT 					= {fg = 11, bg = 0, enabled = true},
		citytells				= {fg = 7,  bg = 0, enabled = true},
		ordertells 				= {fg = 7,  bg = 0, enabled = true},	
		newbie					= {fg = 10, bg = 0, enabled = true},
		emotes 					= {fg = 7,  bg = 0, enabled = true},
		arenatells 				= {fg = 7,  bg = 0, enabled = true},
		market 					= {fg = 7,  bg = 0, enabled = true},
		partytells 				= {fg = 7,  bg = 0, enabled = true},
		armytells 				= {fg = 7,  bg = 0, enabled = true},
		grouptells 				= {fg = 7,  bg = 0, enabled = true},
		riddletalk 				= {fg = 8,  bg = 0, enabled = true},
		shiprace 				= {fg = 8,  bg = 0, enabled = true},
		messages 				= {fg = 3,  bg = 0, enabled = true},
		mail_Messages 			= {fg = 7,  bg = 0, enabled = true},
		news_Messages 			= {fg = 7,  bg = 0, enabled = true},
		rage_Messages 			= {fg = 7,  bg = 0, enabled = true},
		--clantells 			= {fg = 7,  bg = 0, enabled = true},

		-- ROOM DESCRIPTION
		room_title 				= {fg = 10,  bg = 0, enabled = true},
		room_desc 				= {fg = 15,  bg = 0, enabled = true},
		things					= {fg = 6,  bg = 0, enabled = true},
		plant 					= {fg = 5,  bg = 0, enabled = true},
		players 				= {fg = 11, bg = 0, enabled = true},
		exits 					= {fg = 3,  bg = 0, enabled = true},

	}	
	
	for k,v in pairs(t.config.color_sheet) do
		if v.enabled then
			if isPrompt() then deleteFull() end
				t.send("config colour " ..tostring(k).. " " ..v.fg.." "..v.bg)
			end
		end

end	

TReX.config.allowtells=function() 

 	TReX.config.allowtells = {
	
 	"Ysela",
 	"Alrena",
 	"Aegoth",
 	"Laetetia",
 	"Herenicus",
	"Mariya",
 	"Kiet",
 	"Lucianus",
 	 --"" = , -- leaving empty for immediate in game need.
		
 	}
	
	t.send("allowtells remove all", false)
	t.send("config allowtells off", false)
	t.send("config tellsoffmsg I am currently away. Please send me a quick message.", false)

		for k,v in pairs(TReX.config.allowtells) do
			t.send("allowtells add " ..v)
		end	-- for
		
end


TReX.config.compass=function(flee_direction) -- this is nice thing I am working on.

TReX.serverside.prone_check()

if not t.serverside.flee_started then  
	t.serverside.flee_started = true
end
		
t.serverside.flee_direction = flee_direction 

--if already fleeing return
if t.serverside.flee_started then  -- if already tumbling check	--return 
	--if hitting a wall, door, etc.. reset
	if t.serverside.flee_direction == gmcp.Room.WrongDir then 
		t.serverside.flee_started = false
		if isPrompt() then t.serverside.myecho("!WRONG DIRECTION!") end
			return
	end
		
end
		--if sitting from manual sit, override and stand
	if t.serverside["settings"].override then 
		t.serverside["settings"].override = false
			if not (t.affs.aeon) then 
				TReX.serverside.prone_check()
			end
	end -- if override - for auto stand when sitting and you take afflictions.

		t.send("cq eqbal"..cc.."open door "..t.serverside.flee_direction..cc.."queue prepend eqbal go "..t.serverside.flee_direction) -- if not broken legs or no walls then just move direction
			
		if (t.serverside["settings"].debugEnabled) then TReX.debugMessage("( TReX.compass )") end
end


TReX.config.backflip=function(backflip_direction) -- this is nice thing I am working on.

TReX.serverside.prone_check()
tgz.bard.voicecraft.aria_watch = false

if not t.serverside.backflip_started then  
	t.serverside.backflip_started = true
end

t.serverside.backflip_direction = backflip_direction  

-- if already fleeing return
if t.serverside.backflip_started then  
	-- if hitting a wall, door, etc.. reset
	if t.serverside.backflip_direction == gmcp.Room.WrongDir  then 
		t.serverside.backflip_started = false
		if isPrompt() then t.serverside.myecho("!WRONG DIRECTION!") end
			return
	end
		
end

		-- if sitting from manual sit, override and stand
	if t.serverside["settings"].override then 
		t.serverside["settings"].override = false
			if not (t.affs.aeon) then 
				TReX.serverside.prone_check()
			end
	end -- if override - for auto stand when sitting and you take afflictions.
	
	if t.affs.brokenleftleg or t.affs.brokenrightleg or t.affs.damagedleftleg or t.affs.damagedrightleg then
		TReX.rewield(t.inv["cane"].id, "l")
	else	
		TReX.rewield(t.inv["rapier"].id, "l")
	end
		
		if t.serverside.backflip_started then
			enableTimer("backflip started")
			t.send("cq eqbal"..cc.."open door "..t.serverside.backflip_direction..cc.."queue prepend eqbal backflip "..t.serverside.backflip_direction) -- if not broken legs or no walls then just move direction
		end
		
		if (t.serverside["settings"].debugEnabled) then TReX.debugMessage("( TReX.compass )") end
end



TReX.config.somersault=function(somersault_direction) -- this is nice thing I am working on.

TReX.serverside.prone_check()
tgz.bard.voicecraft.aria_watch = false

if not t.serverside.somersault_started then  
	t.serverside.somersault_started = true
end

t.serverside.somersault_direction = somersault_direction  

-- if already fleeing return
if t.serverside.somersault_started then  
	-- if hitting a wall, door, etc.. reset
	if t.serverside.somersault_direction == gmcp.Room.WrongDir  then 
		t.serverside.somersault_started = false
		if isPrompt() then t.serverside.myecho("!WRONG DIRECTION!") end
			return
	end
		
end

		-- if sitting from manual sit, override and stand
	if t.serverside["settings"].override then 
		t.serverside["settings"].override = false
			if not (t.affs.aeon) then 
				TReX.serverside.prone_check()
			end
	end -- if override - for auto stand when sitting and you take afflictions.

	if t.affs.brokenleftleg or t.affs.brokenrightleg or t.affs.damagedleftleg or t.affs.damagedrightleg then
		TReX.rewield(t.inv["cane"].id, "r") -- l = left hand, r= right hand, x=twohands
	else	
		TReX.rewield(t.inv["rapier"].id, "r")
	end
	
		if t.serverside.somersault_started then
			enableTimer("somersault started") 
			t.send("cq eqbal"..cc.."open door "..t.serverside.somersault_direction..cc.."queue prepend eqbal somersault "..t.serverside.somersault_direction) -- if not broken legs or no walls then just move direction
		end

		if (t.serverside["settings"].debugEnabled) then TReX.debugMessage("( TReX.somersault )") end
end

TReX.config.on_click=function(variable, toggle, toggle2)

	if (type(t.serverside["settings"][variable]) == "boolean") then
		if (toggle ~= nil) then
			t.serverside["settings"][variable] = verify(toggle)
		else
			t.serverside["settings"][variable] = not t.serverside["settings"][variable]
		end

		if (t.serverside["settings"][variable]) then -- if toggling to true
			--"parry",
			if table.contains({"parry","deathsight","daina","alleviate","salt","accelerate","fitness","rage","bloodboil","might","shrugging","dragonheal","transmute","meditate","echos","timestamp","override","debugEnabled","restore","paused","Prompt","fool","afflictions","insomnia","vault","reporting","focus","clot","defences","recovery","tree","moss","sipping","do_report"}, variable) then
				t.serverside["settings"][variable] = true 				
			end

			if table.contains({"afflictions","insomnia","vault","reporting","focus","clot","defences","sipping","tree"}, variable) then
				t.serverside["settings_default"][variable] = "Yes"
			end
				--"parry",
				if not table.contains({"parry","deathsight","rage","daina","alleviate","salt","fitness","recovery","bloodboil","accelerate","vault","fool","moss","echos","timestamp","Prompt","restore","tree","might","shrugging","dragonheal","transmute","meditate","override","debugEnabled","paused"}, variable) then
					t.send("curing "..variable.." on", false)
				end


					--if (variable == "deathsight") then
						--t.serverside.green_echo("Will use VISION for DEATHSIGHT")
					--end
				
					if (variable == "transmutation") then
						raiseEvent("TReX precache reset")
						TReX.pipes.epipes()
					end

					if (variable == "moss") then
						t.send("curing mosshealth " ..t.serverside["settings_default"].moss_health_at)
						t.send("curing mossmana " ..t.serverside["settings_default"].moss_mana_at)	
					end							

					if (variable == "clot") then
						t.serverside.settings.clot = true
						t.send("curing clotat 5", false) 
					end

					if (variable == "vault") then
						t.send("curing usevault on", false) 
					end

					if (variable == "defences") then
						TReX.defs.keepup()
					end 
					
					if (variable == "parry") then
						TReX.parry.toggle("on")
					end



			TReX.config.show("settings")
			--t.serverside.green_echo(variable:title().. " ON")

		else -- if toggling to false

			--"parry",
			if table.contains({"parry","deathsight","daina","alleviate","salt","accelerate","fitness","rage","bloodboil","might","shrugging","dragonheal","transmute","meditate","echos","timestamp","override","debugEnabled","restore","paused","Prompt","fool","afflictions","insomnia","vault","reporting","focus","clot","defences","recovery","tree","moss","sipping","do_report"}, variable) then
				t.serverside["settings"][variable] = false
			end
	
			if table.contains({"afflictions","insomnia","vault","reporting","focus","clot","defences","sipping","tree"}, variable) then
				t.serverside["settings_default"][variable] = "No"
			end
				--"parry",
				if not table.contains({"parry","deathsight","rage","daina","alleviate","salt","fitness","recovery","bloodboil","accelerate","vault","fool","moss","echos","timestamp","Prompt","restore","tree","might","shrugging","dragonheal","transmute","meditate","override","debugEnabled","paused"}, variable) then
					t.send("curing "..variable.." off", false)
				end

					--if (variable == "deathsight") then
						--t.serverside.red_echo("Will use NOT use VISION for DEATHSIGHT")
					--end
				
					if (variable == "transmutation") then
						raiseEvent("TReX precache reset")
						TReX.pipes.epipes()
					end

					if (variable == "moss") then
						t.send("curing mosshealth 35", false)
						t.send("curing mossmana 35", false)	
					end							

					if (variable == "vault") then
						t.send("curing usevault off", false) 
					end

					if (variable == "defences") then
						TReX.defs.reset()
					end 
					
					if (variable == "clot") then
						t.serverside.settings.clot = false
						t.send("curing clot off", false) 
					end					
					
					if (variable == "parry") then
						TReX.parry.toggle("off")
					end

			

				TReX.config.show("settings")
				--TReX.config.display(variable:title().. " OFF")

		end

	end
	
end		

TReX.config.sip_health_at=function(num)
	t.serverside["settings_default"].sip_health_at = num
	t.send("curing siphealth " .. num)
	TReX.config.showSettings("settings")
end

TReX.config.sip_mana_at=function(num)
	t.serverside["settings_default"].sip_mana_at = num
	t.send("curing sipmana " .. num)
	TReX.config.showSettings("settings")
end

TReX.config.moss_health_at=function(num)
	t.serverside["settings_default"].moss_health_at = num
	t.send("curing mosshealth " .. num)
	TReX.config.showSettings("settings")
end

TReX.config.moss_mana_at=function(num)
	t.serverside["settings_default"].moss_mana_at = num
	t.send("curing mossmana " .. num)
	TReX.config.showSettings("settings")
end

TReX.config.set_fractures=function(num)
	t.serverside["settings_default"].fractures = num
	t.send("curing healthaffsabove " .. num)
	TReX.config.showSettings("settings")
end

TReX.config.unknown_diagnose_at=function(num)
	t.config["settings_system"].diag_at=num
	TReX.config.showSettings("settings")
end

TReX.config.set_mount=function(num)
	t.send("curing mount "..num)
	t.serverside["settings_default"].mount=num
end

TReX.config.add_mount=function(name, number)
	if not table.contains({mount_list}, name) then
		mount_list[tostring(name)]={["number"]=number, ["enabled"]=false}
	end

	TReX.config.showMounts()
	--cecho("<red>\nMount List\n")
		--for k,v in pairs(mount_list) do
			--TReX.config.display(""..k.."<white>: "..v.number)
		--end
end

TReX.config.remove_mount=function(name)

	if table.contains({mount_list}, name) then
		table.removekey(mount_list, name)
	end

	TReX.config.showMounts()
		--cecho("<red>\nMount List\n")
			--for k,v in pairs(mount_list) do
			--	TReX.config.display(""..k.."<white>: "..v.number)
			--end
end

TReX.config.showSettings=function()
echo("\n")
cecho("\n\t<white>System Settings")
echo("\n")
echo("\n - ") echoLink("Sip Health at", "clearCmdLine() appendCmdLine'sip_health_at '", "sip health") cecho("<white>: "..t.serverside["settings_default"].sip_health_at.." %", false)
echo("\n - ") echoLink("Sip Mana at", "clearCmdLine() appendCmdLine'sip_mana_at '", "sip mana") cecho("<white>: "..t.serverside["settings_default"].sip_mana_at.." %", false)
echo("\n - ") echoLink("Moss Health at", "clearCmdLine() appendCmdLine'moss_health_at '", "moss health") cecho("<white>: "..t.serverside["settings_default"].moss_health_at.." %", false)
echo("\n - ") echoLink("Moss Mana at", "clearCmdLine() appendCmdLine'moss_mana_at '", "moss mana") cecho("<white>: "..t.serverside["settings_default"].moss_mana_at.." %", false)
echo("\n - ") echoLink("Apply to Fractures at", "clearCmdLine() appendCmdLine'set_fractures '", "fractures") cecho("<white>: "..t.serverside["settings_default"].fractures.." %", false)
--echo("\n - ") echoLink("Refill pipes at", "clearCmdLine() appendCmdLine'refill_pipes_at '", "puff count") cecho("<white>: "..t.config["settings_system"].pipes_refill.." puffs", false)
echo("\n - ") echoLink("System will diagnose on", "clearCmdLine() appendCmdLine'unknown_diag_at '", "unknowns") cecho("<white>: "..t.config["settings_system"].diag_at.." unknown", false)
echo("\n")
	
local sortSettings = {}

TReX.class.skill_check()

  for k,v in pairs(t.serverside.settings) do
	if not table.index_of({"debugEnabled","do_report", "paused", "meditate", "installed", "sys_loaded", "sipRingMana", "sipRingHealth", "override"}, k) then
		sortSettings[#sortSettings+1] = k
		table.sort(sortSettings)
	end
  end

	local x = 0
	 			 
		for i, n in ipairs(sortSettings) do
			x = x + 1

		     	d = "<dim_gray>[<white>"

			--if table.index_of(t.stats, n) then

		 		if t.serverside.settings[n] then
		 			d = d .. " <light_blue>+ "
		 		else
		 			d = d .. " <red>- "
		 		end

		 	--end

	     		d = d .. "<dim_gray>]<white> " 


				if (x-1)%3 == 0 then
					echo("\n")
				end  
		
		   	local nWithSpace = n:title()

				if nWithSpace:len() < 25 and (x-1) %3~=2 then
					local pad = 25 - nWithSpace:len()
					nWithSpace = nWithSpace .. string.rep(" ", pad)
				elseif nWithSpace:len() > 25 then
					nWithSpace = nWithSpace:cut(25)
		     	end
	 
			local command

				fg("white")
				cecho(d)
		
			local command = [[TReX.config.on_click("]]..n..[[")]]
			echoLink(nWithSpace, command, "Toggle " .. n, true)

		end
			echo("\n")
			--TReX.stats.prompt_flag = true
			--raiseEvent("TReX prompt")
	
end

TReX.config.show=function (arg,arg2) 
	if arg == nil then
		cecho(b..TReX.menus.main)
	elseif arg == "precache" then
		TReX.precache.manage()
	elseif arg == "tree" then
		TReX.serverside.tree_manage()
	elseif arg == "mount list" then
		TReX.config.showMounts()
	elseif arg == "inventory" then
		TReX.inv.set_id_table()
	elseif arg == "prios" then
		TReX.prios.default_settings()
		TReX.prios.managePrios()
	elseif arg == "defup" then
		TReX.defs.defup_current()
	elseif arg == "keepup" then
		TReX.defs.keepup_current()		
	elseif arg == "defs" then
		TReX.defs.display()
	elseif arg == "lust" then
		TReX.lust.whitelist()
	elseif arg == "settings" then
		TReX.config.showSettings()
	elseif arg == "help file" then
		cecho(TReX.menus.help)
	elseif arg == "setup" then
		cecho(TReX.menus.setup)
	elseif arg=="prompt" then
		TReX.stats.showSettings()
	elseif arg == "about" then
		cecho(TReX.menus.about)
		cechoLink( "<white>\t"..TReX.downloadsURL, [[TReX.downloadNow()]], TReX.downloadsURL, true )
		echo("\n\n\n\n")
	elseif arg == "about" then
		cecho(TReX.menus.about)
	elseif arg == "clan info" then
		cecho(TReX.menus.clan)
	elseif arg == "development" then
		cecho(TReX.menus.development)
	elseif arg == "bugs" then
		cecho(TReX.menus.bug)
		echoLink("\t".."https://github.com/shanesrasmussen/TReX-System/issues", [[openUrl("https://github.com/shanesrasmussen/TReX-System/issues")]], "",false) echo"\n"
	elseif arg == "projects" then
		cecho(TReX.menus.projects)
		echoLink("\t".."https://github.com/shanesrasmussen/TReX-System/projects", [[openUrl("https://github.com/shanesrasmussen/TReX-System/projects")]], "",false) echo"\n"
	--elseif arg == "misc" then
		--cecho(TReX.menus.misc)
	elseif arg == "api" then
		cecho(TReX.menus.api)
	else
		t.echo("Unknown command: <white>"..arg..".")
		t.echo("(enter '<dim_gray>trex<white>' for list of valid commands)")
	end
	
		--elseif arg == "reset" then
		--if arg2 == nil then
			--TReX.reset_player(target)
		--else
		--	TReX.reset_player(arg2)
		--end
	--elseif arg == "report" then TReX.report()
	--elseif arg == "gui" then
		--if arg2 == nil       then TReX.toggle_gui()
		--elseif arg2 == "on"  then TReX.enable_gui()
		--elseif arg2 == "off" then TReX.disable_gui()
		--end
	TReX.stats.prompt_flag = true	
	raiseEvent("TReX prompt")
	
end

TReX.config.save=function() -- saves this file
  if string.char(getMudletHomeDir():byte()) == "/" then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   
   local savePath = getMudletHomeDir() .. _sep .. "TReX_config.lua"
  
      if (io.exists(savePath)) then
		--local s,m = table.save(getMudletHomeDir() .. "profiles/Nehmrah/TReX", TReX.config.lua)
			--if not s then
			--	echof("Couldn't save settings; %s", m)
			--end
		
		table.save(savePath, TReX.config)
		if t.serverside["settings"].echos then TReX.config.echo("Settings Saved") end
	  end -- if
	  
 
end -- func

TReX.config.load=function() --loads it
  if string.char(getMudletHomeDir():byte()) == "/"
   then _sep = "/"
    else _sep = "\\"
     end -- if
   
   local savePath = getMudletHomeDir() .. _sep .. "TReX_config.lua"
   
    if (io.exists(savePath)) then
    table.load(savePath, TReX.config)
    if t.serverside["settings"].echos then TReX.config.echo("Settings Loaded") end
  end -- if

  if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.config.load COMPILED) ") end
  
end -- func

TReX.config.save() 

for _, file in ipairs(TReX.config) do
	dofile(file)
end -- forr