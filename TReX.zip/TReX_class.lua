-- TReX.prios
-- TReX Class Tracking
-- Priority tracking

local send							= send
local cc							= TReX.config.cc or "##"

--- notes to remember tomorrow.. fix dissapearing class enabled value
--- check on t.stacks not loading right.. again.. 

--save offense file
TReX.class.save=function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_class.lua"
   table.save(savePath, TReX.class)
end -- func

--load offense file
TReX.class.load=function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_class.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.class)
	end -- if
end -- func

TReX.class.set=function(a, b, aff) -- this is the function throwing an error


local a = tostring(a)
local b = b or t.target
local aff = tostring(aff)

	if not (t.class[a].enabled) then
		TReX.class.reset()
		t.class[a].enabled = true
	end

		if t.target~=b then
			TReX.tgt.soft(b)
		end
	
		TReX.class[a](aff) 
	

	
end

TReX.class.reset=function()

t.class.list = {
	"alchemist",
	"apostate",
	"bard",
	"blademaster",
	"depthswalker",
	"dragon",
	"druid",
	--"infernal",
	"jester",
	"magi",
	"monk",
	"occultist",
	--"paladin",
	"priest",
	--"runewarden",
	"sentinel",
	"serpent",
	"shaman",
	"sylvan",
	"snb",
	"twoh",
	"dualb",
	"dualc"
}

-- configure t.class = {}
for k,v in ipairs(t.class.list) do
	t.class[v] = {check = TReX.class[v], enabled = false}
end

--TReX.stats.prompt_flag = false
for k,v in ipairs(t.class.list) do
	t.class[v].enabled = false -- sets t.class ie. t.serpent to false
	if TReX.prios.current[k] ~= TReX.prios.default[k] then
		TReX.prios.switchPrios(k,TReX.prios.default[k])
	end
end

	TReX.stats.prompt_flag = true

end -- [[func]]

TReX.class.skill_check=function()

       if table.index_of({"Monk"}, TReX.s.class) then
            t.bals["transmute"] = true 
            t.serverside["settings"].transmute = t.serverside["settings"].transmute or false  
        else 
            t.bals["transmute"] = nil
            t.serverside["settings"].transmute = nil 
        end

        if table.index_of({"Dragon"}, TReX.s.class) then 
            t.bals["dragonheal"] = true
            t.serverside["settings"].dragonheal = t.serverside["settings"].dragonheal or false 
        else
            t.bals["dragonheal"] = nil 
            t.serverside["settings"].dragonheal = nil 
        end

        if table.index_of({"Occultist","Jester"}, TReX.s.class) then
            t.bals["fool"] = true
            t.serverside["settings"].fool = t.serverside["settings"].fool or false
        else
            t.bals["fool"] = nil 
            t.serverside["settings"].fool = nil
        end

        if table.index_of({"Serpent"}, TReX.s.class) then
            t.bals["shrugging"] = true
            t.serverside["settings"].shrugging = t.serverside["settings"].shrugging or false 
        else
            t.bals["shrugging"] = nil
            t.serverside["settings"].shrugging = nil
        end

        if table.index_of({"Magi"}, TReX.s.class) then
            t.bals["bloodboil"] = true
            t.serverside["settings"].bloodboil = t.serverside["settings"].bloodboil or false
        else
            t.bals["bloodboil"] = nil
            t.serverside["settings"].bloodboil = nil
        end
		
		if table.index_of({"Depthswalker"}, TReX.s.class) then
            t.bals["accelerate"] = true
            t.serverside["settings"].accelerate = t.serverside["settings"].accelerate or false
        else
            t.bals["accelerate"] = nil
            t.serverside["settings"].accelerate = nil
        end

		if table.index_of({"Blademaster"}, TReX.s.class) then
            t.bals["alleviate"] = true
            t.serverside["settings"].alleviate = t.serverside["settings"].alleviate or false
        else
            t.bals["alleviate"] = nil
            t.serverside["settings"].alleviate = nil
        end		

		-- if table.index_of({"Shaman"}, TReX.s.class) then
            -- t.bals["daina"] = true
            -- t.serverside["settings"].daina = t.serverside["settings"].daina or false
        -- else
            -- t.bals["daina"] = nil
            -- t.serverside["settings"].daina = nil
        -- end	
		
		if table.index_of({"Alchemist"}, TReX.s.class) then
            t.bals["salt"] = true
            t.serverside["settings"].salt = t.serverside["settings"].salt or false
        else
            t.bals["salt"] = nil
            t.serverside["settings"].salt = nil
        end	
		
        if table.index_of({"Runewarden","Infernal","Paladin"}, TReX.s.class) then 
            t.bals["rage"] = true
            t.serverside["settings"].rage = t.serverside["settings"].rage or false  
        else 
            t.bals["rage"] = nil
            t.serverside["settings"].rage = nil 
        end

        if table.index_of({"Sentinel","Druid"}, TReX.s.class) then 
            t.bals["might"] = true
			t.serverside["settings"].might = t.serverside["settings"].might or false  
        else 
            t.bals["might"] = nil
            t.serverside["settings"].might = nil 
        end		
		
        if table.index_of({"Runewarden","Infernal","Paladin","Blademaster","Monk","Sylvan","Druid","Sentinel"}, TReX.s.class) then
            t.bals["fitness"] = true
            t.serverside["settings"].fitness = t.serverside["settings"].fitness or false
                
                if TReX.s.class_spec() == "Two Handed" then
                    t.serverside["settings"].recovery = false
                else	
					t.serverside["settings"].recovery = nil
				end

        else 
            t.bals["fitness"] = nil
            t.serverside["settings"].fitness = nil
            t.serverside["settings"].recovery = nil
        end


end

TReX.prios.managePrios=function()

  	cecho("\n\t<white>[<MediumSpringGreen>TReX<white>]: Priority list\n\n", false)

  for item,num in TReX.config.spairs(TReX.prios.default, function(t,a,b) return t[b] < t[a] end) do

   		echo(" ")
        cechoLink("<dim_gray>[ <light_blue>+<dim_gray> ]", [[TReX.prios.shuffleUp("]]..item..[[",]]..num..[[)]], "shuffle " .. item .. " up.", true)
        echo(" ")
        cechoLink("<dim_gray>[ <red>-<dim_gray> ]", [[TReX.prios.shuffleDown("]]..item..[[",]]..num..[[)]], "shuffle " .. item .. " down.", true)
        resetFormat()
        cecho(" <dim_grey>[ <white>"..num.."<dim_grey> ] <gray>" .. item .. " \n")  --dark_orchid

  end
		--TReX.stats.prompt_flag = true
		--raiseEvent("TReX prompt")

end

TReX.prios.shuffleDown=function(item, num)

	TReX.prios.default[item]=tonumber(num-1)
	t.send("curing priority "..item.." "..tonumber(num-1))
	--TReX.config.saveSettings()
	TReX.prios.managePrios()

end

TReX.prios.shuffleUp=function(item, num)

	TReX.prios.default[item]=tonumber(num+1)
	t.send("curing priority "..item.." "..tonumber(num+1))
	--TReX.config.saveSettings()
	TReX.prios.managePrios()

end

TReX.prios.login_reset=function()
	if not TReX.prios.default then
		TReX.prios.default_settings()
	end

	for k,v in pairs(TReX.prios.default) do
		t.send("curing priority " .. k .. " " .. tostring(v), false)
		TReX.prios.current[k] = TReX.prios.default[k]
	end
end
	
TReX.prios.aff_reset_by_number=function(k)
	for k,v in pairs(TReX.prios.default) do
		if TReX.prios.current[k] ~= TReX.prios.default[k] then
			TReX.prios.switchPrios(k, TReX.prios.default[k])
		end
	end
end
	
TReX.prios.reset=function()
	for k,v in pairs(TReX.prios.default) do
		if TReX.prios.current[k] ~= TReX.prios.default[k] then
			t.send("curing priority " .. k .. " " .. tostring(v), false)
		end
		TReX.prios.current[k] = TReX.prios.default[k]
	end
end
  
TReX.prios.switchPrios=function(aff, pos, x)

if x == 1 and TReX.prios.current[aff] ~= tonumber(pos) then 
	if isPrompt() then t.serverside.red_echo(""..aff:upper().." <red>[<white>"..tonumber(pos).."<red>]") end
end

	if TReX.prios.current[aff] ~= pos then
		t.send("curing priority "..aff.." "..pos, false)
		TReX.prios.current[aff] = pos
	end

		
		
		if t.serverside["settings"].debugEnabled then 
			--if isPrompt() then 
				t.serverside.red_echo(" "..aff:upper().." <white>( <red>prio swap <white>)") 
			--end 
		end
	
	
end
 
TReX.prios.affPrioChanged=function( aff, pos )
	if pos == 1 or pos == 2 or pos == 8 then
		TReX.prios.current[aff] = tonumber(pos)
	else
		TReX.prios.switchPrios( aff, pos )
	
	end
end

TReX.prios.affPrioRestore=function( aff )

if not TReX.prios.default then -- fail safe
	TReX.prios.default_settings()
end

	if TReX.prios.current[aff] ~= TReX.prios.default[aff] then 
		t.send("curing priority "..aff.." "..TReX.prios.default[aff])
		TReX.prios.current[aff] = TReX.prios.default[aff]
	end
end

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.class loaded successfully) ") end

TReX.class.save()

for _, file in ipairs(TReX.class) do
	dofile(file)
end -- for
