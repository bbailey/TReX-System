-- TReX.parry
-- parry stuff

--debugEnabled						= false 				-- hard debugs -- programmer echos
local send							= send
local cc							= TReX.config.cc or "`" --change to be the character used for concatenation


TReX.parry.check=function()

	getlimb = getlimb or false

		-- if slc.percentages["head"] >= 1 then
			parry_limb = 
			{
				"left leg",
				"right leg"
			}
		--end

    	--if table.contains({parry_limb}, slc.getHighestStack()) --[[or TReX.parry.limbprepped()]] then -- 
		--	parry_limb[getlimb] = tostring(slc.getHighestStack())
		--	return parry_limb[getlimb]
		--else
			--print(#parry_limb)
			getlimb = math.random(1, #parry_limb)
			return parry_limb[getlimb] 
		--end

end


  -- if isDragon() then
  --   ("clawparry " .. wsys.toparry)
  -- elseif is("monk") then
  --   ("guard " .. wsys.toparry)
  -- else
  --   ("parry " .. wsys.toparry)
  -- end -- if

TReX.parry.toggle=function(mode)
	if mode == "on" then
		TReX.parry.on = true
		t.serverside["settings"].parry = true
		TReX.parry.limb()
		t.serverside.green_echo("Parry On")
	else
		TReX.parry.on = false
		t.serverside["settings"].parry = false
		t.serverside.red_echo("Parry Off")
		t.send("parry nothing",false)
	end
				
end  
  
TReX.parry.limb=function() 

	--if parry enabled in menu 'tshow s'
	if t.serverside["settings"].parry then

		if TReX.parry.default == nil then
			TReX.parry.default = TReX.parry.check()
			if not (parry_sent) then

				if t.serverside["settings"].parry then	
					t.send("parry " .. tostring(TReX.parry.check()), false)
				end

							
				if TReX.s.class == "Bard" then
					if t.class["dualc"].enabled then
						if t.serverside["settings"].parry then	
							t.send("trueparry arms",false)
						end
					else
						if t.serverside["settings"].parry then	
							t.send("trueparry centre",false)
						end
					end
				end
				
				parry_sent = true -- check to prevent multiple parry cmd send
				tempTimer(1, [[parry_sent = false]])
			end

		end

		if TReX.parry.default ~= TReX.parry.check() and not parry_sent then -- to prevent spamming <<<< so if it spams its cause this isnt doing the job.
				
				if t.serverside["settings"].parry then	
					t.send("parry " .. tostring(TReX.parry.check()), false)
				end

							
				if TReX.s.class == "Bard" then
					if t.serverside["settings"].parry then	
						t.send("trueparry centre",false)
					end
				end
				

			parry_sent = true -- check to prevent multiple parry cmd send
			tempTimer(1, [[parry_sent = false]])	
		end
	
	end

	if (t.serverside["settings"].debugEnabled) then TReX.debugMessage(" ( TReX.parry.limb ) ") end

end


--save parry file
TReX.parry.save = function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_parry.lua"
   table.save(savePath, TReX.parry)
end -- func

--load parry file
TReX.parry.load = function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_parry.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.parry)
	end -- if
end -- func



if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.parry loaded successfully) ") end

TReX.parry.save()

for _, file in ipairs(TReX.parry) do
	dofile(file)
end -- for