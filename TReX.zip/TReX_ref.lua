-- TReX.ref
-- Reference tables

local send              = send
local cc                = TReX.config.cc or "##"

TReX.ref.aff2venom={

	deafblind				= "colocasia",
	anorexia				= "slike",
	crippledleg				= "epseth",
	clumsiness				= "xentio",
	darkshade				= "darkshade",
	voyria					= "voyria",
	asleep					= "delphinium",
	weariness				= "vernalius",
	slickness				= "gecko",
	selarnia				= "selarnia",
	stupidity				= "aconite",
	illness					= "euphorbia",
	shyness					= "digitalis",
	sensitivity				= "prefarar",
	scytherus				= "scytherus",
	recklessness			= "eutypteria",
	dizziness				= "larkspur",
	haemophilia				= "notechis",
	paralysis				= "curare",
	asthma					= "kalmia",
	addiction				= "vardrax",
	disloyalty				= "monkshood"
}

TReX.ref.kelpaffs={
	"asthma",
	"clumsiness",
	"healthleech",
	"hypochondria",
	"sensitivity",
	"weariness"
}

TReX.ref.arrowColour={
	curare					= "red",
	delphinium				= "blue",
	prefarar				= "purple",
	kalmia					= "white",
	aconite					= "gold",
}

TReX.ref.arena={
	"Matsuhaman Arena, the",
	"Theatrum Mortalis, the",
	"Stadia Coronae, the",
	"Coloseum Diabolus, the",
	"Collosea edn Duir, the",
	"Ainghaeal's Nest",
	"The Gauntlet",
}

TReX.ref.dragon={
	black					= "acid",
	blue					= "ice",
	green					= "venom",
	gold					= "psi",
	red						= "dragonfire",
	silver					= "lightning",
}

TReX.ref.skills={
	class = {
		alchemist			= {"alchemy",			"physiology",		"formulation"},
		apostate			= {"evileye",			"necromancy",		"apostasy"},
		bard				= {"swashbuckling",		"voicecraft",		"harmonics"},
		blademaster			= {"twoarts",			"striking",			"shindo"},
		depthswalker  		= {"aeonics",    		 "shadowmancy",     "terminus"},
		dragon				= {"dragoncraft"}, -- split into separate colours?
		druid				= {"groves",			"metamorphosis",	"reclamation"},
		infernal			= {"necromancy",		"weaponmastery",	"chivalry"},
		jester				= {"tarot",				"pranks",			"puppetry"},
		magi				= {"elementalism",		"crystalism",		"artificing"},
		monk				= {"tekura",			"kaido",			"telepathy"},
		occultist			= {"occultism",			"tarot",			"domination"},
		paladin				= {"devotion",			"weaponmastery",	"chivalry"},
		priest				= {"spirituality",		"devotion",			"healing"},
		runewarden			= {"runelore",			"weaponmastery",	"chivalry"},
		sentinel			= {"woodlore",			"metamorphosis",	"skirmishing"},
		serpent				= {"subterfuge",		"venom",			"hypnosis"},
		shaman				= {"spiritlore",		"curses",			"vodun"},
		sylvan				= {"groves",			"propagation",		"weatherweaving"},
	},
	generic = {
		"battlerage", "riding", "seafaring", "survival", "tattoos", "vision", "weaponry",
	}
}

TReX.ref.defences={
  alertness				= {name = "Alertness",			skillset = {"vision"},},
  bedevilaura			= {name = "Bedevil Aura",		skillset = {"healing"},},
  belltattoo			= {name = "Bell Tattoo",		skillset = {"tattoos"}, manualcommand = "touch bell",},
  blindness				= {name = "Blindness",			skillset = {"curative"},},
  clinging				= {name = "Clinging",			skillset = {"survival"},},
  cloak					= {name = "Cloak",				skillset = {"tattoos"},},
  coldresist			= {name = "Coldresist",			skillset = {"enchantment"},},
  curseward				= {name = "Curseward",			skillset = {"survival"},},
 -- deflect				= {name = "Deflect",			skillset = {"weaponmastery"}, manualcommand = "deflect",},
  deafness				= {name = "Deafness",			skillset = {"curative"},},
  --deathsight			= {name = "Deathsight",			skillset = {"vision", "necromancy"}, manualcommand = kln.manualdeathsight(),},
  density				= {name = "Mass/Density",		skillset = {"curative"},},
  earthshield			= {name = "Earthshield",		skillset = {"healing"},},
  --enduranceblessing	= {name = "Endurance",			skillset = {"healing"},},
  fangbarrier			= {name = "Sileris",			skillset = {"curative"},},
  firefly				= {name = "Firefly",			skillset = {"tattoos"}, manualcommand = "touch firefly",},
  fireresist			= {name = "Fire resist",		skillset = {"enchantment"},},
  electricresist		= {name = "Electric resist",	skillset = {"enchantment"},},
  magicresist			= {name = "Magic resist",		skillset = {"enchantment"},},
  poisonresist			= {name = "Poison resist",		skillset = {"curative"},},
  frostshield 			= {name = "Frostshield",		skillset = {"healing"},},
  fury					= {name = "Fury",				skillset = {"chivalry"},},
  gripping				= {name = "Gripping",			skillset = {"chivalry"},},
  groundwatch			= {name = "Groundwatch",		skillset = {"vision"},},
  heldbreath			= {name = "Hold Breath",		skillset = {"survival"},},
  hypersight			= {name = "Hypersight",			skillset = {"vision"},},
  insomnia				= {name = "Insomnia",			skillset = {"survival"},},
  insulation			= {name = "Insulation",			skillset = {"curative"},},
  kola					= {name = "Kola",				skillset = {"curative"},},
  levitating			= {name = "Levitating",			skillset = {"curative"},},
  lifevision			= {name = "Lifevision",			skillset = {"artefact"},},
  lifegiver				= {name = "Lifegiver",			skillset = {"relic"},},
  metawake				= {name = "Metawake",			skillset = {"survival"},},
  mindseye				= {name = "Mindseye",			skillset = {"tattoos"},},
  mounted				= {name = "Mounted",			skillset = {"riding"},},
  nightsight			= {name = "Nightsight",			skillset = {"vision"},},
  rebounding			= {name = "Rebounding",			skillset = {"curative"},},
  resistance			= {name = "Resistance",			skillset = {"chivalry"},},
  --scholasticism		= {name = "Myrrh",				skillset = {"curative"}, manualcommand = manualmyrrh(),},
  selfishness			= {name = "Selfishness",		skillset = {"survival"},},
  shield				= {name = "Shield",				skillset = {"tattoos"},},
  shroud				= {name = "Shroud",				skillset = {"artefact"},},
  softfocusing			= {name = "Softfocus",			skillset = {"vision"},},
  speed					= {name = "Speed",				skillset = {"curative"},},
  skywatch				= {name = "Skywatch",			skillset = {"vision"},},
  standingfirm			= {name = "Sturdiness",			skillset = {"kaido", "shindo", "chivalry"},},
  starburst				= {name = "Starburst",			skillset = {"tattoos"}, manualcommand = "touch starburst",},
  temperance			= {name = "Frost",				skillset = {"curative"},},
  thermalshield			= {name = "Thermalshield",		skillset = {"healing"},},
  thirdeye				= {name = "Thirdeye",			skillset = {"vision"},},
  treewatch				= {name = "Treewatch",			skillset = {"vision"},},
  weathering			= {name = "Weathering",			skillset = {"chivalry"},},
  scales         		= {name = "Scales",             skillset = {"subterfuge"},},
  secondsight          	= {name = "Secondsight",        skillset = {"subterfuge"},},
  lipreading          	= {name = "Lipreading",         skillset = {"subterfuge"},},

}

TReX.ref.defstrip={
  ["aura of rebounding defence"]		= "rebounding",
  ["mastery of bladecraft"]				= "blademastery",
  ["standing firm"]						= "standingfirm",
  ["gripping"]							= "gripping",
  ["resistance"]						= "resistance",
  ["lifevision"]						= "lifevision",
  ["weathering"]						= "weathering",
  ["frost Spiritshield"]				= "frostshield",
  ["thermal Spiritshield"]				= "thermalshield",
  ["metawake"]							= "metawake",
  ["levitating"]						= "levitating",
  ["deafness"]							= "deafness",
  ["alertness"]							= "alertness",
  ["groundwatch"]						= "groundwatch",
  ["curseward"]							= "curseward",
  ["nightsight"]						= "nightsight",
  ["third eye"]							= "thirdeye",
  ["soft focusing"]						= "softfocusing",
  ["insulation"]						= "insulation",
  ["selfishness"]						= "selfishness",
  ["blindness"]							= "blindness",
  ["density"]							= "density",
  ["anti-weapon field"]					= "rebounding",
  ["kola"]								= "kola",
  ["belltattoo"]						= "belltattoo",
  ["skywatch"]							= "skywatch",
  ["hypersight"]						= "hypersight",
  ["telesense"]							= "telesense",
  ["vigilance"]							= "vigilance",
  ["mindseye"]							= "mindseye",
  ["temperance"]						= "temperance",
  ["fire resistance"]					= "fireresist",
  ["magic resistance"]					= "magicresist",
  ["deathsight"]						= "deathsight",
  ["electric resistance"]				= "electricresist",
  ["treewatch"]							= "treewatch",
  ["cloak"]								= "cloak",
  ["insomnia"]							= "insomnia",
  ["speed"]								= "speed",
  ["venom"]								= "poisonresist",
  ["clinging"]							= "clinging",
  ["shield"]							= "shield",
  ["scholasticism"]						= "scholasticism",
  ["firefly"]							= "firefly",
  ["held breath"]						= "heldbreath",
}

--save ref file
TReX.ref.save=function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_ref.lua"
   table.save(savePath, TReX.ref)
end -- func

--load ref file
TReX.ref.load=function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_ref.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.ref)
	end -- if
end 
-- even started that hehehe started coding stuff here and there.

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.ref loaded successfully) ") end

TReX.ref.save()

for _, file in ipairs(TReX.ref) do
	dofile(file)
end -- for