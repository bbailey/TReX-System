-- TReX.c2
-- Achaea config capture

local send							= send
local cc							= TReX.config.cc or "##"

TReX								= TReX or {}
TReX.config							= TReX.config or {}
TReX.config.channels				= TReX.config.channels or {}
TReX.config.channels.data			= TReX.config.channels.data or {}

--save c2 file
TReX.config.save=function()
  if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
  	else
		_sep = "\\"
   end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_c2.lua"
   table.save(savePath, TReX.config)
end -- func

--load c2 file
TReX.config.load=function()
if (string.char(getMudletHomeDir():byte()) == "/") then
		_sep = "/"
    else 
		_sep = "\\"
end -- if
   local savePath = getMudletHomeDir() .. _sep .. "TReX_c2.lua"
	if (io.exists(savePath)) then
		table.load(savePath, TReX.c2)
	end -- if
end -- func

TReX.config.channels.capture=function(chn, fg, bg)

	if t.serverside["settings"].debugEnabled then TReX.debugMessage("Hitting channels capture") end
	local chncol = TReX.config.channels.data
	
	local rTbl = {}
	local r = false
	
	if not chncol[chn] then				-- entry not found in table, needs to be added
		--table.insert(chncol,#chncol+1,[chn]={fg,bg})
		TReX.debugMessage("Inserting "..chn)
		chncol[chn] = {fg,bg}
	
	else												-- entry in table
		if chncol[chn][1] ~= fg or
		  chncol[chn][2] ~= bg then						-- something has changed
			if chncol.update then						-- update table
				chncol[chn][1] = fg
				chncol[chn][2] = bg
			end
		
		else											-- log changes
			rTbl[chn] = {fg,bg}
			r = true
			
		end
	end
	
	-- rollback changes
	if r then for k,v in pairs(rTbl) do t.send("CONFIG COLOR "..k.." "..v[1].." "..v[2], false) end end

end

TReX.config.channels.send=function(updt)

	local trig = "config - channel colours"

	if TReX.config.channels.capturing then return end	-- prevent looping
	if TReX.config.channels.timer then killTimer(TReX.config.channels.timer) TReX.config.channels.timer = nil end

	if updt then TReX.config.channels.update = true end
	
	TReX.config.channels.timer = tempTimer(2, function()				-- timeout just in case of d/c or lag
	
		if TReX.config.channels.timer then killTimer(TReX.config.channels.timer) TReX.config.channels.timer = nil end
		disableTrigger(trig)
		TReX.config.channels.capturing = nil
		TReX.config.channels.update = nil
	
	end)
	
	enableTrigger(trig)
	tempTimer(0+(getNetworkLatency()*.1),[[t.send("config color", false)]])
		
end

-- EXACT MATCH: Your current colour configuration is as follows:
-- open trigger

-- EXACT MATCH: Basic Available Colours:
-- close trigger

-- REGEX: ^(\w+)\s+?(\d+)\s+(\d+)\s+?\(?.+\,?\s+?\"?.+\.\"?$
-- capture information
-- TReX.config.channels.capture(matches[2], matches[3], matches[4])

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.c2 loaded successfully) ") end

for _, file in ipairs(TReX.config) do
	dofile(file)
end -- for