-- TReX.queue
-- Queue management
-- LOTS TO DO HERE, DON'T USE AT THE MOMENT
-- currently only allows queueing of serverside commands, to be expanded to allow clientside commands

local send							= send
local cc							= TReX.config.cc or "##"
local b								= TReX.bals					-- now we can use b instead of TReX.bals
local q								= TReX.queue				-- now we can use q instead of TReX.queue

local default_queue_priority		= 25

local proneAffs={			--<< this is new					-- affs which prevent actions, recode later to use TReX aff names (TReX.aff[x]?)
	"aeon",														-- Klen, the tem uses it just how you have it coded.aeon is 'aeon', paralysis is 'paralysis'. 
	"bound",													-- reference TReX_serverside.lua for aff names in the table called t.serverside.afflictions{}. 
	"entangled",
	"paralysis",
	"prone",
	"stun",
	"transfixation",
	"impaled",
	"webbed",
	"roped" -- missed one :P
}

-- need a list of trigger lines for failing actions
-- prone
-- stun
-- blackout
-- aeon

TReX.queue.func={							-- functions

	setup=function()

	local string
	local string_set = matches[3]
		-- building them here to avoid conflicts in the xml
		TReX.queue.trig.doq = tempExactMatchTrigger("[System]: Running queued eqbal command: TReXDo",
			[[
				TReX.queue.func.doSent("doq")
				deleteFull()
			]]
		)
		
		TReX.queue.trig.dor = tempExactMatchTrigger("[System]: Running queued eqbal command: TReXDoR",
			[[
				TReX.queue.func.doSent("dor")
				deleteFull()
			]]
		)
		
		TReX.queue.trig.doFree = tempRegexTrigger("^\[System\]\: Running queued (?:balance|equilibrium) command\: DOFREE(\d+)$",
			[[
				TReX.queue.func.doFreeClear()
				deleteFull()
			]]
		)
		
		TReX.queue.trig.doFreeSet = tempRegexTrigger("^Alias \"TReXDoFree(\d+)\" will now execute: \"(.+)\"$",
			[[
				TReX.queue.cmds["TReXDoFree"..string] = string_set
				deleteFull()
			]]
		)
		
		TReX.queue.trig.doSet = tempRegexTrigger("^Alias \"TReXDo\" will now execute: \"(.+)\"$",
			[[
				TReX.queue.cmds["TReXDo"] = matches[2]
			]]
		)
		
		TReX.queue.trig.doAdd = tempExactMatchTrigger("[System]: Added TReXDo to your eqbal queue.",
			[[
				selectString("TReXDo",1)
				bg("black") fg("firebrick")
				replace(TReX.queue.cmds["TReXDo"])
				resetFormat()
				deselect()
			]]
		)
		
		TReX.queue.trig.dorSet = tempRegexTrigger("^Alias \"TReXDoR\" will now execute\: \"(.+)\"$",
			[[
				TReX.queue.cmds["TReXDoR"] = matches[2]
			]]
		)
		
		TReX.queue.trig.dorAdd = tempExactMatchTrigger("[System]: Added TReXDoR to your eqbal queue.",
			[[
				selectString("TReXDoR",1)
				bg("black") fg("firebrick")
				replace(TReX.queue.cmds["TReXDoR"])
				resetFormat()
				deselect()
			]]
		)
	end,
	
	pause=function()
	
		for _, t in ipairs(TReX.queue.trig) do
			disableTrigger(TReX.queue.trig[t])
		end
		
	end,
	
	unpause=function()
	
		for _, t in ipairs(TReX.queue.trig) do
			enableTrigger(TReX.queue.trig[t])
		end
		q.doSend()

	end,

-- DO FREE QUEUE
	doFreeAdd=function(action, prepend, silent)
	
		local ac = action:upper()
		local qsize = #q.doFree
		local ppd = "ADD"
		if prepend then ppd = "PREPEND" end
		
		if qsize < 7 then
			send("SET ALIAS TReXDoFree"..tostring(qsize+1).." "..ac, not silent)
			send("QUEUE "..ppd.." "..q.func.selectDoFreeQueue().." TReXDoFree "..tostring(qsize+1), not silent)
			q.doFree[qsize+1] = ac
		else
			if t.serverside["settings"].echos then q.func.echo("<red>DOFREE QUEUE FULL! Couldn't add "..action) end
		end
	end,

	selectDoFreeQueue=function()
	
		if b.bal and bals.eq then
			return "bal"
		elseif b.bal and not (b.eq) then
			return "eq"
		elseif not (b.bal) and b.eq then
			return "bal"
		elseif not (b.bal) and not (b.eq) then
			return "bal"
		end

	end,
  
	doFreeRemove=function(n)
		if tonumber(n) then										-- will return nil if not a number
			q.func.doFree[tonumber(n)] = nil
		end
	end,
	
	doFreeClear=function()
		q.func.doFree = {}
	end,

-- DO QUEUE
	insert=function(queue, itm, priority, lifo)				--queue[i] = { itm = "action", priority = [1-N] }
	
		local inserted = false
		for idx, itm in ipairs(queue) do
			if priority < itm.priority or						-- new action is lower priority so insert
			  priority == itm.priority and lifo					-- same priority and lifo
			  then
				table.insert(queue,index,{itm = action, priority = priority} )
				inserted = true
				break
			end

			if not (inserted) then									-- add to end
				table.insert(queue,index,{itm = action, priority = priority})
			end
		end
	end,
	
	doAdd=function(itm, priority, silent)

		q.func.insert( q.doQueue, { itm = action, silent = silent }, priority or default_queue_priority )
		q.func.doSend()

	end,
	
	doPpd=function(action, priority, silent)
	
		q.func.insert (q.doQueue, { itm = action, silent = silent }, priority or default_queue_priority, true)
		q.func.doSend()
	
	end,
	
	doSend=function()
	
		if not (TReX.timer.doWait) then
			if next(q.doQueue) then
				if q.doQueued and q.doQueue_pending and q.doQueue_pending.itm.action == q.doQueue[1].itm.action then
					return										-- action is next queued, no need to re-queue
				end
				
				TReX.timer.doWait = tempTimer(getNetworkLatency()*3, [[TReX.timer.doWait = nil]] )
				t.send("SET ALIAS TReXDo "..q.doQueue[1].action, not q.doQueue[1].itm.silent )
				q.cmds["TReXDo"] = q.doQueue[1].action
				q.doQueued = true
				t.send("QUEUE ADD EQBAL TReXDo", not q.doQueue[1].itm.silent )
				local tmp = q.doQueue[1]
				if q.doQueue_pending then						-- re-queue interrupted command
					q.doQueue[1] = q.doQueue_pending
				else
					table.remove(q.doQueue, 1)
				end
				q.doQueue_pending = tmp
				
			elseif q.repeating and not TReX.useLyre then
				TReX.timer.doWait = tempTimer(getNetworkLatency()*1.5, [[TReX.timer.doWait = nil]])
				t.send("QUEUE ADD EQBAL TReXDoR")
				if TReX.timer.dorFailsafe then killTimer(TReX.timer.dorFailsafe) end
				TReX.timer.dorFailsafe = tempTimer(3.5, [[TReX.timer.dorFailsafe = nil; if b.bal and b.eq then q.doSend() end ]] )
			end
		end

	end,
	
	doSent=function(type)
	
		raiseEvent("TReX queue "..type)
		q.doQueued 				= false
		q.doQueue_pending		= nil
		if TReX.timer.doWait then killTimer(TReX.timer.doWait) TReX.timer.doWait = nil end
		if TReX.timer.dorFailsafe then killTimer(TReX.timer.dorFailsafe) TReX.timer.dorFailsafe = nil end
		q.func.doSend()
	
	end,
	
	-- list contents
	-- remove first entry
	-- reset list
	
	doFailsafes=function()

		q.doQueued = false
		q.func.doFreeClear()
	
	end,

	dorSet=function(action)
	
		q.dorAction = action
		t.send("SET ALIAS TReXDoR "..q.dorAction, false)
		q.func.doSend()
		
	end,
	
	dorClear=function()
	
		q.dorAction = false
		t.send("CLEARQUEUE EQBAL", false)
		if t.serverside["settings"].echos then q.func.echo("Cleared the repeated action") end
		
	end,
	
 -- ECHO
	echo=function(what,command,popup)

		what = "<firebrick>[<plum>TReX<firebrick>]<reset><white> " .. what
		-- apply newline if required
		moveCursorEnd("main")
		if getCurrentLine() ~= "" then what = "\n"..what.."\n" end
		if command then
			cechoLink(what, command, popup or "", true)
		else
			if t.serverside["settings"].echos then cecho("\n"..what.."\n") end
		end
	
	end,
	
}

registerAnonymousEventHandler("TReX gained bal", "TReX.queue.func.doFailsafes")

if t.serverside["settings"].debugEnabled then TReX.debugMessage(" (TReX.queues loaded successfully) ") end